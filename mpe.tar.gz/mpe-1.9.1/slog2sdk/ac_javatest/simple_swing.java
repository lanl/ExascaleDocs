import javax.swing.*;

public class simple_swing
{
    public static void main( String args[] )
    {
        // JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        System.exit( 0 );
    }
}
