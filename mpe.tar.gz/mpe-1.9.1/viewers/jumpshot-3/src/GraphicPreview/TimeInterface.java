
public interface TimeInterface
{
    public void showTime(double time_clicked);
    public void closePreview();
}
