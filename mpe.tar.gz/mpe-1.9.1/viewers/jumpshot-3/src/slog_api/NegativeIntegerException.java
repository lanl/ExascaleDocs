public class NegativeIntegerException extends Exception
{
    public NegativeIntegerException()
    {
        super();
    }

    public NegativeIntegerException( String str )
    {
        super( str );
    }
}
