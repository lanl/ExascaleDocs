import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StatPlotr extends JFrame
{
    public static void main(String args[])
    {
	StatisticsViewer graph_pane = new StatisticsViewer();
	graph_pane.setVisible(true);
    }
}
    
        
	
	
