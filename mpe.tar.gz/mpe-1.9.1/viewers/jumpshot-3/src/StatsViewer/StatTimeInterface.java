
public interface StatTimeInterface
{
    public void showTime(double time_clicked);
    public void closePreview();
}
