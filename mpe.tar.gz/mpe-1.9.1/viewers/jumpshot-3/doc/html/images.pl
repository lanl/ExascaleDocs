# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/resizebox*{0.2textwidth}{!}{includegraphics{picslashstatview_legends_sm.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="146" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.gif"
 ALT="\resizebox*{0.2\textwidth}{!}{\includegraphics{pic/statview_legends_sm.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashpreview.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="420" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/preview.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashmainwin.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="90" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/mainwin.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashpreview_few.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="420" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/preview_few.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashtimeline_thread_all_zoomed.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="409" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/timeline_thread_all_zoomed.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashtimeline_thread_all_zoomed_defs.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="83" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/timeline_thread_all_zoomed_defs.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashtimeline_thread_all.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="409" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/timeline_thread_all.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslasharrow_histogram.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="357" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/arrow_histogram.ps}}">|; 

$key = q/resizebox*{0.7textwidth}{!}{includegraphics{picslashtimeline_manipulations.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="389" HEIGHT="217" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img12.gif"
 ALT="\resizebox*{0.7\textwidth}{!}{\includegraphics{pic/timeline_manipulations.ps}}">|; 

$key = q/resizebox*{0.8textwidth}{!}{includegraphics{picslashstatview_main_sm.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="444" HEIGHT="303" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.gif"
 ALT="\resizebox*{0.8\textwidth}{!}{\includegraphics{pic/statview_main_sm.ps}}">|; 

$key = q/resizebox*{0.9textwidth}{!}{includegraphics{picslashpreview_line.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="420" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.gif"
 ALT="\resizebox*{0.9\textwidth}{!}{\includegraphics{pic/preview_line.ps}}">|; 

$key = q/resizebox*{0.3textwidth}{!}{includegraphics{picslashpreview_legends.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="167" HEIGHT="284" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.gif"
 ALT="\resizebox*{0.3\textwidth}{!}{\includegraphics{pic/preview_legends.ps}}">|; 

$key = q/resizebox*{0.3textwidth}{!}{includegraphics{picslashpreview_legends_few.ps}};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="167" HEIGHT="317" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.gif"
 ALT="\resizebox*{0.3\textwidth}{!}{\includegraphics{pic/preview_legends_few.ps}}">|; 

1;

