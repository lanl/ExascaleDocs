class Info {
  double begT;
  double endT;
  double lenT;
  boolean blink = false;

  public Info () {}
}
