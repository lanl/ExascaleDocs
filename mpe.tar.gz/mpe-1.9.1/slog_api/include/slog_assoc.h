#if !defined ( _SLOG )
#include "slog.h"
#endif  /*  if !defined ( _SLOG )  */

int SLOG_Assoc_IsEqualTo( const SLOG_N_assocs_t   Nassocs1,
                          const SLOG_assoc_t     *assocs1,
                          const SLOG_N_assocs_t   Nassocs2,
                          const SLOG_assoc_t     *assocs2 );
