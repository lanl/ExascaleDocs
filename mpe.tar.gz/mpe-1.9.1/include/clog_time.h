/* where timestamps come from */

void   CLOG_timeinit ( void );
double CLOG_timestamp ( void );

